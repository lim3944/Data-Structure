#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node {
	int vertex;
	int priority;
}Node;


int main(int argc, char** argv) {
	FILE* ifp;
	ifp = fopen(argv[1], "r+");
	char nodenum[200];
	char *p = nodenum;
	int** adja;
	int* gajung;
	int i, j, noden, offset;
	int a, b, min, idx, first, start;
	int nodereal[200];
	int noderev[200];
	int isend[200];
	int queue[100];
	int allend = 1;
	int qidx = 0;
	int result[200];
	int ridx = 0;

	fscanf(ifp, " %[^\n]", nodenum);
	noden = 1;

	for (i = 0; i < 1000; i++) {
		result[i] = 9999;
	}

	while (sscanf(p, "%d%n", &a, &offset) != EOF) {
		nodereal[noden] = a;
		noderev[a] = noden;
		noden++;

		p += offset;
	}

	adja = (int**)malloc((noden + 1) * sizeof(int*));
	for (i = 1; i <= noden; i++) {
		adja[i] = (int*)malloc((noden + 1) * sizeof(int));
	}
	for (i = 1; i <= noden; i++) {
		for (j = 1; j <= noden; j++) {
			adja[i][j] = 987654321;
		}
	}
	first = 1;
	while (fscanf(ifp, "%d-%d-%d", &a, &b, &idx) != EOF) {
		adja[noderev[a]][noderev[b]] = idx;

		if (first == 1) {
			start = noderev[a];
			first = 0;
		}
	}
	gajung = (int*)malloc((noden + 1) * sizeof(int));

	for (i = 1; i <= noden; i++) {
		gajung[i] = 987654321;
		isend[i] = 0;
	}
	for (i = 0; i < 100; i++) {
		queue[i] = 0;
	}
	gajung[start] = 0;
	queue[0] = start;
	while (allend) {
		start = queue[0];
		result[ridx] = start;
		ridx++;
		for (i = 1; i <= noden; i++) {
			if (adja[start][i] != 987654321) {
				if (gajung[i] > gajung[start] + adja[start][i]) {
					gajung[i] = gajung[start] + adja[start][i];
				}
			}
		}

		min = 987654321;
		isend[start] = 1;
		for (i = 1; i <= noden; i++) {
			if (min > gajung[i]) {
				min = gajung[i];
			}
		}

		for (i = 1; i <= noden; i++) {
			if (min == gajung[i]) {
				queue[qidx] = i;
				qidx++;
			}
		}

		for (i = 1; i <= noden; i++) {
			if (isend[i] == 1) {
				allend++;
			}
		}

		if (allend == 1 + noden) {
			allend = 0;
		}
		else {
			allend = 1;
		}
	}
	printf("start: %d\n%d", nodereal[result[0]], nodereal[result[0]]);

	/*for (i = 1; i < 1000; i++) {
	if (result[i] == 9999) {
	break;
	}
	printf("->%d", nodereal[result[i]]);
	}*/
	fclose(ifp);
	printf("\n");

	return 0;
}
